import asyncio
import websockets
import json
async def echo(websocket):
    print(websocket.remote_address)
    print(f"New Connection from {websocket.remote_address[0]}")
    async for message in websocket:
        print(message)
        cmd = input('#> ')
        await websocket.send(cmd)
        if websockets.ConnectionClosed:
            continue


async def main():
    async with websockets.serve(echo, "localhost", 8765):
        await asyncio.Future()  # run forever
asyncio.run(main())